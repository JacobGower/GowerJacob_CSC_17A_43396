/* 
 * File:   Prime.h
 * Author: Jacob Gower
 *
 * Created on April 25, 2021, 7:34 PM
 */

#ifndef PRIME_H
#define PRIME_H
struct Prime{
	unsigned short prime;
	unsigned char power;
};


#endif /* PRIME_H */

