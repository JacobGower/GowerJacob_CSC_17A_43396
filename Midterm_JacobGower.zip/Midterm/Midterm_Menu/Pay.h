/* 
 * File:   Pay.h
 * Author: Jacob Gower
 *
 * Created on April 26, 2021, 11:56 PM
 */

#ifndef PAY_H
#define PAY_H
struct Pay{
    string  name,
            engl;
    int  numWrkr,
         hrsWrkd;
    float payRte,
          ttlPay;
    
};


#endif /* PAY_H */

