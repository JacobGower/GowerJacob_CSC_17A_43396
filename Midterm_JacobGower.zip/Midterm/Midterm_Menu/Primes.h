/* 
 * File:   Primes.h
 * Author: Jacob Gower
 *
 * Created on April 25, 2021, 7:34 PM
 */

#ifndef PRIMES_H
#define PRIMES_H
struct Primes{
	unsigned char nPrimes;
	Prime *prime;
};


#endif /* PRIMES_H */

