/* 
 * File:   main.cpp
 * Author: Jacob Gower
 * Created on February 20, 2021, 11:05 AM
 * Purpose:  First Program "Hello World"
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, Higher Dimension Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map Inputs to Outputs -> Process
    
    //Display Inputs/Outputs
    cout<<"Hello World"<<endl;
    
    //Exit the Program - Cleanup
    return 0;
}

