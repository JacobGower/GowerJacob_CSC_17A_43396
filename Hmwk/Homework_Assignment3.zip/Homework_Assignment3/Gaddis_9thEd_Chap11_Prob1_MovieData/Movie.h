/* 
 * File:   Movie.h
 * Author: Jacob Gower
 *
 * Created on April 6, 2021, 7:26 PM
 */

#ifndef MOVIE_H
#define MOVIE_H

struct Movie{
    string title,
         directr;
        int year,
            mins;
};


#endif /* MOVIE_H */

