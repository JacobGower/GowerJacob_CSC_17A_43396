/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MoBdgt.h
 * Author: Jacob Gower
 *
 * Created on April 6, 2021, 7:14 PM
 */

#ifndef MOBDGT_H
#define MOBDGT_H

struct MoBdgt{
    float housing,
          utility,
          hsExpns,
          transpo,
             food,
          medical,
          insrnce,
          entrtan,
          clothes,
             misc,
            total;
};


#endif /* MOBDGT_H */

